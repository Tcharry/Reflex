package com.example.reflex;

import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.Random;

public class GameFragment extends Fragment {

    // Déclaration des variables
    private RelativeLayout mainLayout;
    private Button startButton;
    private Button quitButton;
    private TextView timerTextView;
    private TextView clickTextView;
    private Handler handler = new Handler();
    private long startTime;
    private boolean gameStarted = false;;

    // Constructeur par défaut
    public GameFragment() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate le layout pour ce fragment
        View view = inflater.inflate(R.layout.fragment_game, container, false);

        // Initialisation des vues
        mainLayout = view.findViewById(R.id.main);
        startButton = view.findViewById(R.id.startButton);
        quitButton = view.findViewById(R.id.quitButton);
        clickTextView = view.findViewById(R.id.clickTextView);
        timerTextView = view.findViewById(R.id.timerTextView);

        // Configuration du bouton de démarrage
        startButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startGame();
            }
        });

        // Configuration du bouton de quitter
        quitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (getActivity() != null) {
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            }
        });

        return view; // Retourne la vue créée
    }

    // Méthode pour démarrer le jeu
    private void startGame() {
        // Configuration initiale du jeu
        timerTextView.setText("Wait for it...");
        startButton.setVisibility(View.GONE);
        quitButton.setVisibility(View.GONE);

        // Génération d'un délai aléatoire pour l'écran vert
        Random random = new Random();
        int delay = random.nextInt(5000) + 2000; // Entre 2 et 7 secondes

        // Gestion du clic sur l'écran principal avant l'appariton de l'écran vert (évite les clics prématurés)
        mainLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                gameLost();
            }
        });
        // Affichage de l'écran vert après le délai
        handler.postDelayed(new Runnable() {
            public void run() {
                mainLayout.setBackgroundColor(Color.GREEN);
                clickTextView.setText("Click !");
                startTime = System.currentTimeMillis();
                gameStarted = true;
                updateElapsedTime();

                // Gestion du clic sur l'écran principal au moment de l'appariton de l'écran vert
                mainLayout.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v){
                        if (gameStarted) {
                            long reactionTime = System.currentTimeMillis() - startTime;
                            clickTextView.setVisibility(View.GONE);
                            timerTextView.setText("Time: " + reactionTime + " ms");
                            quitButton.setVisibility(View.VISIBLE);
                            gameStarted = false;
                        }
                    }
                });
            }
        }, delay);
    }

    // Méthode appelée lorsque le joueur a perdu
    private void gameLost() {
        // Arrêt du jeu et affichage du message de défaite
        gameStarted = false;
        handler.removeCallbacksAndMessages(null); // Arrête tous les retards et annule toutes les tâches en attente
        clickTextView.setVisibility(View.GONE);
        timerTextView.setText("You lost !");
        quitButton.setVisibility(View.VISIBLE);
        mainLayout.setBackgroundColor(Color.RED);
    }

    // Méthode pour mettre à jour le temps écoulé depuis le début du jeu
    private void updateElapsedTime() {
        handler.post(new Runnable() {
            public void run() {
                if (gameStarted) {
                    long elapsedTime = System.currentTimeMillis() - startTime;
                    timerTextView.setText(elapsedTime + " ms");
                    handler.postDelayed(this, 10);
                }
            }
        });
    }
}
