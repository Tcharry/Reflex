package com.example.reflex;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class MenuFragment extends Fragment {

    // Interface pour interagir avec l'activité principale
    private OnMenuFragmentInteractionListener mListener;

    // Constructeur par défaut requis pour un fragment
    public MenuFragment() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate le layout pour ce fragment
        View view = inflater.inflate(R.layout.fragment_menu, container, false);

        // Initialisation des vues
        Button playButton = view.findViewById(R.id.playButton);
        Button quitButton = view.findViewById(R.id.quitButton);

        // Définir le comportement du bouton "Play"
        playButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onPlayButtonClicked();
                }
            }
        });

        // Définir le comportement du bouton "Quit"
        quitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getActivity().finish(); // Terminer l'activité et fermer l'application
            }
        });

        return view; // Retourne la vue créée
    }

    // Vérifie si l'activité implémente l'interface de l'écouteur
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnMenuFragmentInteractionListener) {
            mListener = (OnMenuFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnMenuFragmentInteractionListener");
        }
    }

    // Nettoie l'écouteur lorsque le fragment est détaché de l'activité
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Interface pour la communication avec l'activité principale
    public interface OnMenuFragmentInteractionListener {
        void onPlayButtonClicked();
    }
}